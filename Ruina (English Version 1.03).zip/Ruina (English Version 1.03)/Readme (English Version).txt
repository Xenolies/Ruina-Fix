Thank you for playing Ruina: Fairy Tale of the Forgotten Ruins, English edition!

Ruina is a free-to-play Japanese game made with the RPG Maker 2000 engine, originally released on December 24th, 2008 by Shoukichi Karekusa (枯草章吉). It won the Grand Prize in Freem!'s 4th Annual Game Contest.

This translation is based on Ruina Version 1.21, the final released version of the original Japanese edition of the game. It was released with the knowledge and consent of its creator, Shoukichi Karekusa, under the following conditions:

1. That his name remain in or be added to any relevant documentation, signifying that he is the game's creator.
2. That the game always be available free of charge.

If you find that this translation is being sold anywhere or with its credits stripped from its associated files, please let me know.

For full credits, please refer to the Japanese Readme. For more information on this translation, its participants, and any ongoing fixes or alterations, please visit https://dinklations.wordpress.com/ (which is probably how you got here, but just in case someone else decided to host the game somewhere).

Enjoy!

Dink
dinklations@gmail.com
/u/EnormousHatred